=== WP Bootstrap Gallery ===
Contributors:magnigenie,sagarseth9
Tags: Image Gallery, Boostrap Gallery, Bootstrap Image Gallery,Gallery Plugin, Wordpress Image Gallery Plugin, WP Bootstrap Gallery
Requires at least: 3.4.0
Tested up to: 5.2
Requires PHP: 5.4
Stable tag: 1.1
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=sales@magnigenie.com&item_name=WP%20Bootstrap%20Gallery&return=http://magnigenie.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Boootstrap Gallery  is the ultra responsive image gallery plugin for WordPress which works seamlessly on every device. 

== Description ==

WP Boootstrap Gallery  is the ultra responsive image gallery plugin for WordPress which works seamlessly on every device. This plugin uses the power of Twitter Bootstrap Using this plugin you can easily create multiple image gallery and add them to any post,page or custom post type. The plugin comes with a simple one click installation.

= Key features: =

* Fully responsive image gallery with gesture support for mobile devices. 
* Easy to use admin interface. 
* Bulk upload fearure. 
* Functionality to create gallery out of all the attachments available on your site. 
* Easy to add gallery to any post,page or even custom post types just by putting the shortcode on the content editor. 
* Select between title/file name/alt text/caption to use as the caption for the images. 
* Easily switch between WordPress thumbnail generator and Timthumb.
* Specify custom image sizes for Timthumb images. 
* Option to switch between full screen gallery and normal gallery. 
* Option to have border less and bordered gallery. Gallery settings to switch default functionality. 
* Drag and Drop interface to easily order the images in a gallery.

Check out the [Demo here](http://magnigenie.com/wp-bootstrap-gallery-wordpress-image-gallery-plugin/).

= Important Notes =
This plugin is based on  [blueimp jquery gallery plugin](https://github.com/blueimp/Bootstrap-Image-Gallery).

If you have any  suggestions for a new plugin, feel free to email me at sagarseth9@gmail.com.

== Installation ==

1. Go to your admin area and select Plugins -> Add new from the menu.
2. Search for "WP Bootstrap Gallery".
3. Click install.
4. Click activate.
5. Go to WPB Gallery and add new gallery.

== Frequently Asked Questions ==
= How to use WP Bootstrap Gallery? =

This plugin comes with very user friendly user interface. You just need to install it and then navigate to WPB Gallery on wordpress admin and add a new gallery. When you are done with adding gallery images just save it and then you can see a shortcode for each gallery you have created. Just copy the shortcode and put in any post/page or even custom post type.


== Screenshots ==

1. Check out [the demo](http://magnigenie.com/wp-bootstrap-gallery-wordpress-image-gallery-plugin/) for more screenshots and demo .

== ChangeLog ==

= Version 1.1 =

* Added option to download image.
* Added option for social sharing of images.

= Version 1.0 =

* Initial public release.

== Upgrade Notice ==

= Version 1.1 =

* A new update for WP Bootstrap Gallery is available to download.